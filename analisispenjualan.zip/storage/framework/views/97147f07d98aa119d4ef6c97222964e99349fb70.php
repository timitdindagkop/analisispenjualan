<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($title); ?></title>
</head>
<body>
    <style type="text/css">
        body{
        font-family: sans-serif;
        }
        table{
        margin: 20px auto;
        border-collapse: collapse;
        }
        table th,
        table td{
        border: 1px solid #3c3c3c;
        padding: 3px 8px;
        }
        .tengah{
            text-align: center;
        }
    </style>
    <h2 class='tengah'>Pembelian Barang</h2>
    
    <p class='tengah'>Tertanggal : <?php echo e(date('d/m/Y', strtotime($pembelian->tanggal))); ?></p>
    <br/>
    <table>
        <tr>
            <th width="5%">No</th>
            <th width="25%">Kode barang</th>
            <th width="25%">Nama barang</th>
            <th width="10%">Jumlah</th>
            <th width="20%">Harga</th>
            <th width="20%">Nominal</th>
        </tr>
        <?php $__currentLoopData = $detail_pembelian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($item->barang->kode_barang); ?></td>
                <td><?php echo e($item->barang->nama_barang); ?></td>
                <td><?php echo e($item->jumlah); ?></td>
                <td>Rp. <?php echo e(number_format($item->harga, 0, ',', '.')); ?></td>
                <td>Rp. <?php echo e(number_format($item->harga*$item->jumlah, 0, ',', '.')); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td colspan="5" style="text-align: right"><strong>Total</strong></td>
            <td><strong>Rp. <?php echo e(number_format($pembelian->total_uang,0,',','.')); ?></strong></td>
        </tr>
    </table>
    <p style="margin-left: 68%"><?php echo e(auth()->user()->name); ?></p>
    <br><br><br><br>
    <p style="margin-left: 65%">(&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;)</p>
</body>
<script>
    print()
</script>
</html>
<?php /**PATH C:\xampp\htdocs\analisispenjualan\resources\views/pembelian/print.blade.php ENDPATH**/ ?>
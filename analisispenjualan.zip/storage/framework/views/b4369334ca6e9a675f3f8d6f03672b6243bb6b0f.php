
<?php $__env->startSection('container'); ?>
    <!-- Start Content-->
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <h4 class="page-title"><?php echo e($title); ?></h4>
                    <div class="page-title-right">
                        <ol class="breadcrumb p-0 m-0">
                            <li class="breadcrumb-item"><a href="#">Laporan</a></li>
                            <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                        </ol>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="col-lg-7 col-md-7">
                <div class="card">
                    <div class="card-body">
                        <h4>Data besaran Pendapatan</h4>
                        <div class="table-responsive">
                            <table id="penjualan" class="table table-bordered mb-0">
                                <thead>
                                    <tr class="text-center">
                                        <th width="5%">#</th>
                                        <th width="30%">Tanggal(X)</th>
                                        <th width="65%">Jumlah Barang(Y)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="text-center">
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item['bulan']); ?></td>
                                        <td><?php echo e($item['penjualan']); ?> Kilo</td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 col-md-5">
                <div class="card">
                    <div class="card-body">
                        <h4>Penyederhadaan Data</h4>
                        <div class="table-responsive">
                            <table id="penjualan" class="table table-bordered mb-0">
                                <thead>
                                    <tr class="text-center">
                                        <th width="5%">No</th>
                                        <th width="30%">X</th>
                                        <th width="65%">Y</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="text-center">
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item['tgl']); ?></td>
                                        <td><?php echo e($item['penjualan']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h4>Nilai Perhitungan</h4>
                        <div class="table-responsive">
                            <table id="penjualan" class="table table-bordered mb-0">
                                <thead>
                                    <tr class="text-center">
                                        <th width="5%">No</th>
                                        <th width="15%">X</th>
                                        <th width="15%">Y</th>
                                        <th width="20%">X2</th>
                                        <th width="20%">Y2</th>
                                        <th width="25%">XY</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="text-center">
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item['tgl']); ?></td>
                                        <td><?php echo e($item['penjualan']); ?></td>
                                        <td><?php echo e($item['tgl'] * $item['tgl']); ?></td>
                                        <td><?php echo e($item['penjualan']*$item['penjualan']); ?></td>
                                        <td><?php echo e($item['tgl']*$item['penjualan']); ?></td>
                                    </tr>
                                    <?php $totalno += $loop->iteration; ?>
                                    <?php $totalx += $item['tgl']; ?>
                                    <?php $totaly += $item['penjualan']; ?>
                                    <?php $totalx2 += $item['tgl']*$item['tgl']; ?>
                                    <?php $totaly2 += $item['penjualan'] * $item['penjualan']; ?>
                                    <?php $totalxy += $item['tgl'] * $item['penjualan']; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><strong>Total</strong></td>
                                    <td><strong><?php echo e($totalx); ?></strong></td>
                                    <td><strong><?php echo e($totaly); ?></strong></td>
                                    <td><strong><?php echo e($totalx2); ?></strong></td>
                                    <td><strong><?php echo e($totaly2); ?></strong></td>
                                    <td><strong><?php echo e($totalxy); ?></strong></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5>Menghitung nilai Konstanta (a) dan koefisien (b)</h5>
                    <?php $konstanta_a = (($totaly*$totalx2) - ($totaly*$totalxy)) / (($totalno*$totalx2) - ($totalx*$totalx) )  ?>
                    <?php $koefisien_b = (($totalno*$totalxy) - ($totalx*$totaly)) / (($totalno*$totalx2) - ($totalx*$totalx) )  ?>
                        <div class="table-responsive">
                            <table class="table table-bordered mb-0">
                                <tr class="text-center">
                                    <td><strong>Konstantan A</strong></td>
                                    <td><strong>Konstantan B</strong></td>
                                </tr>
                                <tr class="text-center">
                                    <td><strong><?php echo e($konstanta_a); ?></strong></td>
                                    <td><strong><?php echo e($koefisien_b); ?></strong></td>
                                </tr>
                            </table>
                        </div>
                        <?php $nilaiY = $konstanta_a + ($koefisien_b*$totalx)  ?>
                        <h5>Nilai dari persamaan dengan menggunakan metode regresi linear sederhana adalah sebagai berikut dimana Y = <strong><?php echo e(round($nilaiY)); ?></strong> <br />
                        Maka estimasi Stok barang pada besok hari tanggal <?php echo e(date('d-m-Y', strtotime('+1 day'))); ?> adalah sekitar <?php echo e(round($nilaiY)); ?> Kilo</h5>
                    </div>
                </div>
            </div>
        </div>
        <!-- end row -->
    </div>
    <!-- end container-fluid -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\analisispenjualan\resources\views/analisis/index.blade.php ENDPATH**/ ?>
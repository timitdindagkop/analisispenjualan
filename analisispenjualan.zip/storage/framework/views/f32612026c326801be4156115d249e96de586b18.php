<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Cetak Struk</title>
</head>

<body>
    <table>
        <thead>
            <tr>
                <th colspan="3"><h4>Toko Lil Luk Ma</h4></th>
            </tr>
            <tr>
                <th colspan="3">Jl. Kota pekalongan</th>
            </tr>
            <tr>
                <th colspan="3">
                    <hr size="2px" color="black" />
                </th>
            </tr>
            <tr>
                <th colspan="3" style="text-align: right"> Tgl : <?php echo e(date('d M Y', strtotime($data->tanggal))); ?></th>
            </tr>
            <tr>
                <th colspan="3"><br></th>
            </tr>
            <tr>
                <th colspan="3" style="text-align: left">No invoice #<?php echo e($data->id); ?></th>
            </tr>
            <tr>
                <th colspan="3"><hr></th>
            </tr>
            <tr>
                <th style="text-align: left">Barang</th>
                <th style="text-align: left">Jml</th>
                <th style="text-align: left">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($d->barang->nama_barang); ?></td>
                    <td style="text-align: center"><?php echo e($d->jumlah); ?></td>
                    <td>Rp. <?php echo e(number_format($d->harga*$d->jumlah,0, ',','.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="3"><hr></td>
            </tr>
            <tr>
                <td colspan="2"><strong>Total</strong></td>
                <td>Rp. <?php echo e(number_format($data->total_uang,0, ',','.')); ?></td>
            </tr>
            <tr>
                <td colspan="3"><br></td>
            </tr>
            <tr>
                <td colspan="3" style="text-align: center">Terima Kasih</td>
            </tr>
            <tr>
                <td colspan="3"><hr /><hr /></td>
            </tr>
        </tbody>
    </table>
</body>
<script>
    print()
</script>
</html><?php /**PATH C:\xampp\htdocs\analisispenjualan\resources\views/penjualan/print.blade.php ENDPATH**/ ?>